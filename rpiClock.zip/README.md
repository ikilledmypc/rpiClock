# rpiClock

My alarm clock broke down so I decided to utillize this opportunity to use my old rpi 1 for a permanent project. 

the project currently uses a 2x16 lcd in combination with 1 transistor on GPOI18 for brightness control. 

the system displays the current time and date and is able to display messages for a set amount of time before it goes back to displaying the time. By visiting a web page on port 8080 alarms can be set for custom times in hour and minutes(the clock currently only displays an alarm message as I am still working on sound) 
